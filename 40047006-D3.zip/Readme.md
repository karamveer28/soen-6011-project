1.Folder LatexPackage includes the latex source code,report generated and collection of all screen shorts attached.

2.D3LatexCode is a pdf file containing the source code of latex used to generate the report.

3.Deliverable 3 is pdf file of report generated for review.